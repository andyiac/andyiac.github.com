﻿<?php
require_once("class.smtp.php");
$smtpserver = "smtp.163.com";
$smtpserverport = 25;
$smtpusermail = "18600575356@163.com";
$smtpemailto = "pxl@kh95.com";
$smtpuser = "18600575356";
$smtppass = "StmP!163?passWO";
$mailsubject = "快货-反馈";
$mailsubject = "=?UTF-8?B?".base64_encode($mailsubject)."?=";
$mailbody = $_POST['value_content'];
$mailtype = "HTML";
$smtp = new smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);
$smtp->debug = TRUE;//是否显示发送的调试信息
$smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype);
?>