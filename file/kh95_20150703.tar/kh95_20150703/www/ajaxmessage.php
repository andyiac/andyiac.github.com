﻿<?php
    //短信接口用户名 $uid
    $uid = 'SDK2410';
    //短信接口密码 $passwd
    $passwd = 'gmygO2mQmvhsusHc';
    //发送到的目标手机号码 $telphone
    $telphone = $_GET['value_telphone'];
    //短信内容 $message
    date_default_timezone_set('Asia/Shanghai');
    $message = "尊敬的用户，欢迎使用快货服务！点击链接：http://dwz.cn/En2aM 下载快货安卓客户端 ".date("H").":". sprintf("%02d", floor (date("i")/2)*2);
    //$message = iconv("gb2312","utf-8//IGNORE",$message);(如果出现乱码需强制转换)
    $message =rawurlencode($message);
    $gateway = "http://api.bjszrk.com/sdk/BatchSend.aspx?CorpID={$uid}&Pwd={$passwd}&Mobile={$telphone}&Content={$message}&Cell=&SendTime=";
    $result = file_get_contents($gateway);
    echo $result;

?>