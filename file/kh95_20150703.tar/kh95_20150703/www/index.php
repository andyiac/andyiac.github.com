﻿<?php
include("Mobile_Detect.php");
$detect = new Mobile_Detect();

if ($detect->isMobile()) {
    // any mobile platform
    Header ( "Location: ./download/down.html" );
}
else{
}
?>




<!DOCTYPE html>
<html>
<head lang="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="Keywords" Content="快货,kuaihuo,物流,货物" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="快货是一款通过综合运用移动互联网技术，帮助物流公司、货主迅速发货调车，货车司机迅速配货的双向信息平台。" />
    <title>快货——发货就用快货</title>
    <link rel="shortcut icon" href="img/html_icon.ico" />

    <script src="http://libs.useso.com/js/jquery/1.8.3/jquery.min.js"></script>
    <link type="text/css" rel="stylesheet" href="./css/index.css" >

    <link href="./css/toastr.css" rel="stylesheet"/>
    <script src="./js/toastr.js"></script>

</head>
<body>
    <a id="left" href="javascript:void(0);"  onclick="onleft();" onmouseover="onoverleft();" onmouseout="onoutleft()"></a>
    <div id="index01" class="bg_banner bg_banner01">
        <div class="bg_banner_nav">
            <a href="#content" class="bg_banner_content">联系我们</a>
        </div>
        <div class="bg_banner_download">
            <a href="javascript:void(0);" onclick="js_mailgoogle1();" id="mailgoogle1" class="bg_banner_mailgoogle"></a>
            <div id="mailgoogle_click1" class="bg_banner_mailgoogle_click">
                <input type="text" id="mailgoogle_text1" firstValue="请输入手机号" value="请输入手机号" onFocus="onfocus_nameHide('mailgoogle_text1');" onBlur="onblur_nameShow('mailgoogle_text1');" class="bg_banner_mailgoogle_text1" onkeypress="EnterPress1(event)"  oninput="oninput1();" onpropertychange="oninput1();" onclick="onclicktext1();"/>
                <a href="javascript:void(0);" onclick="js_mailgoogle_click1();" id="mailgoogle_a1" class="bg_banner_mailgoogle_a"></a>
            </div>
            <a href="javascript:void(0);" class="bg_banner_downgoogle" data-reveal-id="myModalAndroid" data-animation="fade"></a>
            <a href="javascript:void(0);" class="bg_banner_downweixin" data-reveal-id="myModalWeixin" data-animation="fade"></a>
            <a href="javascript:void(0);" class="bg_banner_downapple" data-reveal-id="myModalApple" data-animation="fade"></a>
        </div>
    </div>

    <div id="index02" class="bg_banner bg_banner02" style="display: none; opacity:0;">
        <div class="bg_banner_nav">
            <a href="#content" class="bg_banner_content">联系我们</a>
        </div>
        <div class="bg_banner_download">
            <a href="javascript:void(0);" onclick="js_mailgoogle2();" id="mailgoogle2" class="bg_banner_mailgoogle bg_banner_mailgoogle_b"></a>
            <div id="mailgoogle_click2" class="bg_banner_mailgoogle_click">
                <input type="text" id="mailgoogle_text2" firstValue="请输入手机号" value="请输入手机号" onFocus="onfocus_nameHide('mailgoogle_text2');" onBlur="onblur_nameShow('mailgoogle_text2');" class="bg_banner_mailgoogle_text2" onkeypress="EnterPress2(event)"   oninput="oninput2();" onpropertychange="oninput2();" onclick="onclicktext2();"/>
                <a href="javascript:void(0);" onclick="js_mailgoogle_click2();" id="mailgoogle_a2" class="bg_banner_mailgoogle_a bg_banner_mailgoogle_a_b"></a>
            </div>
            <a href="javascript:void(0);" class="bg_banner_downgoogle bg_banner_downgoogle_b" data-reveal-id="myModalAndroid" data-animation="fade"></a>
            <a href="javascript:void(0);" class="bg_banner_downweixin bg_banner_downweixin_b" data-reveal-id="myModalWeixin" data-animation="fade"></a>
            <a href="javascript:void(0);" class="bg_banner_downapple bg_banner_downapple_b" data-reveal-id="myModalApple" data-animation="fade"></a>
        </div>
    </div>

    <div id="index03" class="bg_banner bg_banner03" style="display: none; opacity:0;">
        <div class="bg_banner_nav">
            <a href="#content" class="bg_banner_content">联系我们</a>
        </div>
        <div class="bg_banner_download">
            <a href="javascript:void(0);" onclick="js_mailgoogle3();" id="mailgoogle3" class="bg_banner_mailgoogle bg_banner_mailgoogle_b"></a>
            <div id="mailgoogle_click3" class="bg_banner_mailgoogle_click">
                <input type="text" id="mailgoogle_text3" firstValue="请输入手机号" value="请输入手机号" onFocus="onfocus_nameHide('mailgoogle_text3');" onBlur="onblur_nameShow('mailgoogle_text3');" class="bg_banner_mailgoogle_text3" onkeypress="EnterPress3(event)"   oninput="oninput3();" onpropertychange="oninput3();" onclick="onclicktext3();"/>
                <a href="javascript:void(0);" onclick="js_mailgoogle_click3();" id="mailgoogle_a3" class="bg_banner_mailgoogle_a bg_banner_mailgoogle_a_b"></a>
            </div>
            <a href="javascript:void(0);" class="bg_banner_downgoogle bg_banner_downgoogle_b" data-reveal-id="myModalAndroid" data-animation="fade"></a>
            <a href="javascript:void(0);" class="bg_banner_downweixin bg_banner_downweixin_b" data-reveal-id="myModalWeixin" data-animation="fade"></a>
            <a href="javascript:void(0);" class="bg_banner_downapple bg_banner_downapple_b" data-reveal-id="myModalApple" data-animation="fade"></a>
        </div>
    </div>
    <a id="right" href="javascript:void(0);"  onclick="onright();" onmouseover="onoverright();" onmouseout="onoutright()"></a>
    <!--修改 区域 mark-->

    <div id="myModalAndroid" class="reveal-modal">
        <a class="close-reveal-modal">×</a>
        <div id="down_android_div" ></div>
        <p id="down_android_p" >扫描二维码下载 快货for Android</p>
        <a id="down_android_a" href="http://dwz.cn/QdclA">直接下载</a>
    </div>
    <div id="myModalWeixin" class="reveal-modal">
        <a class="close-reveal-modal">×</a>
        <div id="down_weixin_div" ></div>
        <p id="down_weixin_p" >扫描二维码立即使用 快货微信版</p>
    </div>
    <div id="myModalApple" class="reveal-modal">
        <a class="close-reveal-modal">×</a>
        <div id="down_apple_div" ></div>
        <p id="down_apple_p" >扫描二维码下载 快货for iphone</p>
        <a id="down_apple_a" href="http://dwz.cn/QdjMI">直接下载</a>
    </div>

    <!--<div id="myModalAndroid" class="reveal-modal">
        <a class="close-reveal-modal">×</a>
        <div id="down_android_div" ></div>
        <p id="down_android_p" >扫描二维码下载 快货for Android</p>
        <a id="down_android_a" href="javascript:void(0);">直接下载</a>
    </div>
    <div id="myModalApple" class="reveal-modal">
        <a class="close-reveal-modal">×</a>
        <div id="down_apple_div" ></div>
        <p id="down_apple_p" >扫描二维码下载 快货for Apple</p>
        <a id="down_apple_a" href="javascript:void(0);">直接下载</a>
    </div>-->

    <!--修改 区域 mark-->

    <div id="bg_appfunction">
        <p class="over_inner">真正省钱、省事、贴心、懂你的物流互联网应用。快货是帮助物流公司、货主迅速发货调车，货车司机迅速配货的双向信息平台</p>
    </div>
    <div id="bg_appview">
        <p class="over_inner over_inner_appview">页面简洁美观，层次清晰，傻瓜式操作，简单易用。快扫描底部二维码，下载试试吧，你会爱上她！
        </p>
    </div>
    <div id="bg_appdownload">
        <p class="over_inner over_inner_bg_appdownload">物流从业者及有发货需求的人士，扫描底部二维码，开始使用快货吧，马上开启互联网时代的智能物流！<br/>安卓客户端，已在<span class="span_down">360</span>、<span class="span_down">91</span>、<span class="span_down">小米</span>等各大商店发布；关注微信服务号同样可以实现基础功能；苹果客户端将近期推出，敬请期待！
        </p>
        <div style="text-align:center;">
            <div id="bg_appdownloaddiv">
                <div id="appdownload_android"></div>
                <div id="appdownload_apple"></div>
            </div>
        </div>
    </div>
    <a name="content" id="content"></a>
    <div id="bg_email">
        <p class="over_inner over_inner_email">尊敬的用户，您的反馈对我们非常重要，它将直接发到我们公司创始人，我们会悉心聆听，感谢您的给力支持！</p>
        <div id="bg_email_content">
            <p id="bg_email_h1">您好!</p>
            <form>
                <input type="text" id="bg_email_content_name" firstValue="姓名" value="姓名" onFocus="onfocus_nameHide('bg_email_content_name');" onBlur="onblur_nameShow('bg_email_content_name');" />
                <input type="text" id="bg_email_content_phone" firstValue="手机(选填)" value="手机(选填)" onFocus="onfocus_nameHide('bg_email_content_phone');" onBlur="onblur_nameShow('bg_email_content_phone');" />
                <input type="text" id="bg_email_content_mail" firstValue="邮箱" value="邮箱" onFocus="onfocus_nameHide('bg_email_content_mail');" onBlur="onblur_nameShow('bg_email_content_mail');" />
                <textarea rows="3" cols="20" onpropertychange="this.style.posHeight=this.scrollHeight" id="bg_email_content_content" firstValue="内容" onFocus="onfocus_nameHide('bg_email_content_content');" onBlur="onblur_nameShow('bg_email_content_content');" >内容</textarea>
            </form>
            <a href="javascript:sendMail();" id="bg_email_content_button"></a>
        </div>
    </div>
    <div id="bottom_line"></div>
    <div id="bottom_div">
        <p id="bottom_div_p01">北京圆桌骑士科技有限公司</p>
        <p id="bottom_div_p02">Copyright  快货 2014, All Rights Reserved</p>
    </div>

<script>
$("#left").animate({opacity:'0'},1200);
function onoverleft(){
    $("#left").animate({opacity:'1'},200);
}
function onoutleft(){
    $("#left").animate({opacity:'0'},200);
}
$("#right").animate({opacity:'0'},1200);
function onoverright(){
    $("#right").animate({opacity:'1'},200);
}
function onoutright(){
    $("#right").animate({opacity:'0'},200);
}



(function($) {

    /*---------------------------
     Defaults for Reveal
     ----------------------------*/

    /*---------------------------
     Listener for data-reveal-id attributes
     ----------------------------*/

    $('a[data-reveal-id]').live('click', function(e) {
        e.preventDefault();
        var modalLocation = $(this).attr('data-reveal-id');
        $('#'+modalLocation).reveal($(this).data());
    });

    /*---------------------------
     Extend and Execute
     ----------------------------*/

    $.fn.reveal = function(options) {


        var defaults = {
            animation: 'fadeAndPop', //fade, fadeAndPop, none
            animationspeed: 300, //how fast animtions are
            closeonbackgroundclick: true, //if you click background will modal close?
            dismissmodalclass: 'close-reveal-modal' //the class of a button or element that will close an open modal
        };

        //Extend dem' options
        var options = $.extend({}, defaults, options);

        return this.each(function() {

            /*---------------------------
             Global Variables
             ----------------------------*/
            var modal = $(this),
                    topMeasure  = parseInt(modal.css('top')),
                    topOffset = modal.height() + topMeasure,
                    locked = false,
                    modalBG = $('.reveal-modal-bg');

            /*---------------------------
             Create Modal BG
             ----------------------------*/
            if(modalBG.length == 0) {
                modalBG = $('<div class="reveal-modal-bg" />').insertAfter(modal);
            }

            /*---------------------------
             Open & Close Animations
             ----------------------------*/
            //Entrance Animations
            modal.bind('reveal:open', function () {
                modalBG.unbind('click.modalEvent');
                $('.' + options.dismissmodalclass).unbind('click.modalEvent');
                if(!locked) {
                    lockModal();
                    if(options.animation == "fadeAndPop") {
                        modal.css({'top': $(document).scrollTop()-topOffset, 'opacity' : 0, 'visibility' : 'visible'});
                        modalBG.fadeIn(options.animationspeed/2);
                        modal.delay(options.animationspeed/2).animate({
                            "top": $(document).scrollTop()+topMeasure + 'px',
                            "opacity" : 1
                        }, options.animationspeed,unlockModal());
                    }
                    if(options.animation == "fade") {
                        modal.css({'opacity' : 0, 'visibility' : 'visible', 'top': $(document).scrollTop()+topMeasure});
                        modalBG.fadeIn(options.animationspeed/2);
                        modal.delay(options.animationspeed/2).animate({
                            "opacity" : 1
                        }, options.animationspeed,unlockModal());
                    }
                    if(options.animation == "none") {
                        modal.css({'visibility' : 'visible', 'top':$(document).scrollTop()+topMeasure});
                        modalBG.css({"display":"block"});
                        unlockModal()
                    }
                }
                modal.unbind('reveal:open');
            });

            //Closing Animation
            modal.bind('reveal:close', function () {
                if(!locked) {
                    lockModal();
                    if(options.animation == "fadeAndPop") {
                        modalBG.delay(options.animationspeed).fadeOut(options.animationspeed);
                        modal.animate({
                            "top":  $(document).scrollTop()-topOffset + 'px',
                            "opacity" : 0
                        }, options.animationspeed/2, function() {
                            modal.css({'top':topMeasure, 'opacity' : 1, 'visibility' : 'hidden'});
                            unlockModal();
                        });
                    }
                    if(options.animation == "fade") {
                        modalBG.delay(options.animationspeed).fadeOut(options.animationspeed);
                        modal.animate({
                            "opacity" : 0
                        }, options.animationspeed, function() {
                            modal.css({'opacity' : 1, 'visibility' : 'hidden', 'top' : topMeasure});
                            unlockModal();
                        });
                    }
                    if(options.animation == "none") {
                        modal.css({'visibility' : 'hidden', 'top' : topMeasure});
                        modalBG.css({'display' : 'none'});
                    }
                }
                modal.unbind('reveal:close');
            });

            /*---------------------------
             Open and add Closing Listeners
             ----------------------------*/
            //Open Modal Immediately
            modal.trigger('reveal:open')

            //Close Modal Listeners
            var closeButton = $('.' + options.dismissmodalclass).bind('click.modalEvent', function () {
                modal.trigger('reveal:close')
            });

            if(options.closeonbackgroundclick) {
                modalBG.css({"cursor":"pointer"})
                modalBG.bind('click.modalEvent', function () {
                    modal.trigger('reveal:close')
                });
            }
            $('body').keyup(function(e) {
                if(e.which===27){ modal.trigger('reveal:close'); } // 27 is the keycode for the Escape key
            });

            scall()
            /*---------------------------
             Animations Locks
             ----------------------------*/
            function unlockModal() {
                locked = false;
            }
            function lockModal() {
                locked = true;
            }

        });//each call
    }//orbit plugin call
})(jQuery);






/*
 *
 * Copyright (c) 2014 Daniele Lenares (https://github.com/Ryuk87)
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php)
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 *
 * Version 0.5.1
 *
 */
(function(e){function t(e,t,n){if(t=="show"){switch(n){case"fade":e.fadeIn();break;case"slide":e.slideDown();break;default:e.fadeIn()}}else{switch(n){case"fade":e.fadeOut();break;case"slide":e.slideUp();break;default:e.fadeOut()}}}e.goup=function(n){var r=e.extend({location:"right",locationOffset:20,bottomOffset:10,containerRadius:10,containerClass:"goup-container",arrowClass:"goup-arrow",alwaysVisible:false,trigger:500,entryAnimation:"fade",goupSpeed:"slow",hideUnderWidth:500,containerColor:"#000",arrowColor:"#fff",title:"",titleAsText:false,titleAsTextClass:"goup-text"},n);e("body").append('<div style="display:none" class="'+r.containerClass+'"></div>');var i=e("."+r.containerClass);e(i).html('<div class="'+r.arrowClass+'"></div>');var s=e("."+r.arrowClass);var o=r.location;if(o!="right"&&o!="left"){o="right"}var u=r.locationOffset;if(u<0){u=0}var a=r.bottomOffset;if(a<0){a=0}var f=r.containerRadius;if(f<0){f=0}var l=r.trigger;if(l<0){l=0}var c=r.hideUnderWidth;if(c<0){c=0}var h=/(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i;if(h.test(r.containerColor)){var p=r.containerColor}else{var p="#000"}if(h.test(r.arrowColor)){var d=r.arrowColor}else{var d="#fff"}if(r.title===""){r.titleAsText=false}var v={};v={position:"fixed",width:40,height:40,background:p,cursor:"pointer"};v["bottom"]=a;v[o]=u;v["border-radius"]=f;e(i).css(v);if(!r.titleAsText){e(i).attr("title",r.title)}else{e("body").append('<div class="'+r.titleAsTextClass+'">'+r.title+"</div>");var m=e("."+r.titleAsTextClass);e(m).attr("style",e(i).attr("style"));e(m).css("background","transparent").css("width",80).css("height","auto").css("text-align","center").css(o,u-20);var g=e(m).height()+10;e(i).css("bottom","+="+g+"px")}var y={};y={width:0,height:0,margin:"0 auto","padding-top":13,"border-style":"solid","border-width":"0 10px 10px 10px","border-color":"transparent transparent "+d+" transparent"};e(s).css(y);var b=false;e(window).resize(function(){if(e(window).outerWidth()<=c){b=true;t(e(i),"hide",r.entryAnimation);if(m)t(e(m),"hide",r.entryAnimation)}else{b=false;e(window).trigger("scroll")}});if(e(window).outerWidth()<=c){b=true;e(i).hide();if(m)e(m).hide()}if(!r.alwaysVisible){e(window).scroll(function(){if(e(window).scrollTop()>=l&&!b){t(e(i),"show",r.entryAnimation);if(m)t(e(m),"show",r.entryAnimation)}if(e(window).scrollTop()<l&&!b){t(e(i),"hide",r.entryAnimation);if(m)t(e(m),"hide",r.entryAnimation)}})}else{t(e(i),"show",r.entryAnimation);if(m)t(e(m),"show",r.entryAnimation)}if(e(window).scrollTop()>=l&&!b){t(e(i),"show",r.entryAnimation);if(m)t(e(m),"show",r.entryAnimation)}e(i).on("click",function(){e("html,body").animate({scrollTop:0},r.goupSpeed);return false});e(m).on("click",function(){e("html,body").animate({scrollTop:0},r.goupSpeed);return false})}})(jQuery)





var autoTextarea = function (elem, extra, maxHeight) {
    extra = extra || 20;
    var isFirefox = !!document.getBoxObjectFor || 'mozInnerScreenX' in window,
            isOpera = !!window.opera && !!window.opera.toString().indexOf('Opera'),
            addEvent = function (type, callback) {
                elem.addEventListener ?
                        elem.addEventListener(type, callback, false) :
                        elem.attachEvent('on' + type, callback);
            },
            getStyle = elem.currentStyle ? function (name) {
                var val = elem.currentStyle[name];
                if (name === 'height' && val.search(/px/i) !== 1) {
                    var rect = elem.getBoundingClientRect();
                    return rect.bottom - rect.top -
                    parseFloat(getStyle('paddingTop')) -
                    parseFloat(getStyle('paddingBottom')) + 'px';
                };

                return val;
            } : function (name) {
                return getComputedStyle(elem, null)[name];
            },
            minHeight = parseFloat(getStyle('height'));
    elem.style.maxHeight = elem.style.resize = 'none';
    var change = function () {
        var scrollTop, height,
                padding = 0,
                style = elem.style;
        if (elem._length === elem.value.length) return;
        elem._length = elem.value.length;

        if (!isFirefox && !isOpera) {
            padding = parseInt(getStyle('paddingTop')) + parseInt(getStyle('paddingBottom'));
        };
        scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
        elem.style.height = minHeight + 'px';
        if (elem.scrollHeight > minHeight) {
            if (maxHeight && elem.scrollHeight > maxHeight) {
                height = maxHeight - padding;
                style.overflowY = 'auto';
            } else {
                height = elem.scrollHeight - padding;
                style.overflowY = 'hidden';
            };

            style.height = height + extra + 'px';
            scrollTop += parseInt(style.height) - elem.currHeight;
            document.body.scrollTop = scrollTop;
            document.documentElement.scrollTop = scrollTop;
            elem.currHeight = parseInt(style.height);
        };
    };
    addEvent('propertychange', change);
    addEvent('input', change);
    addEvent('focus', change);
    change();
};


autoTextarea(document.getElementById('bg_email_content_content'));



function onleft(){
    if(timebanner2 != 0) {
    clearTimeout(timebanner2);
    }
    if(timebanner3 != 0){
        clearTimeout(timebanner3);
    }
    if(timebanner1 != 0){
        clearTimeout(timebanner1);
    }



    if($("#index01").css("display")!="none"){
        $("#index01").animate({opacity:'0.2'},400,function(){
            $("#index01").css({display:'none'})
            $("#index03").css({opacity:'0.2'})
            $("#index03").css({display:'block'})
            $("#index03").animate({opacity:'1'},1200);
        })
        timebanner3=setTimeout(function(){

            $("#index03").animate({opacity:'0.2'},400,function(){
                $("#index03").css({display:'none'})
                $("#index01").css({opacity:'0.2'})
                $("#index01").css({display:'block'})
                $("#index01").animate({opacity:'1'},1200);
            })
            banner_timer()
        },8000);
    }
    else{
        if($("#index02").css("display")!="none") {

            $("#index02").animate({opacity:'0.2'},400,function(){
                $("#index02").css({display:'none'})
                $("#index01").css({opacity:'0.2'})
                $("#index01").css({display:'block'})
                $("#index01").animate({opacity:'1'},1200);
            })
            banner_timer()
        }
        else{
            if($("#index03").css("display")!="none") {

                $("#index03").animate({opacity:'0.2'},400,function(){
                    $("#index03").css({display:'none'})
                    $("#index02").css({opacity:'0.2'})
                    $("#index02").css({display:'block'})
                    $("#index02").animate({opacity:'1'},1200);
                })
                timebanner2=setTimeout(function(){

                    $("#index02").animate({opacity:'0.2'},400,function(){
                        $("#index02").css({display:'none'})
                        $("#index03").css({opacity:'0.2'})
                        $("#index03").css({display:'block'})
                        $("#index03").animate({opacity:'1'},1200);
                    })
                    timebanner3=setTimeout(function(){

                        $("#index03").animate({opacity:'0.2'},400,function(){
                            $("#index03").css({display:'none'})
                            $("#index01").css({opacity:'0.2'})
                            $("#index01").css({display:'block'})
                            $("#index01").animate({opacity:'1'},1200);
                        })
                        banner_timer()
                    },8000);
                },8000);
            }
        }
    }




}

function onright(){
    if(timebanner2 != 0) {
        clearTimeout(timebanner2);
    }
    if(timebanner3 != 0){
        clearTimeout(timebanner3);
    }
    if(timebanner1 != 0){
        clearTimeout(timebanner1);
    }



    if($("#index01").css("display")!="none"){

        $("#index01").animate({opacity:'0.2'},400,function(){
            $("#index01").css({display:'none'})
            $("#index02").css({opacity:'0.2'})
            $("#index02").css({display:'block'})
            $("#index02").animate({opacity:'1'},1200);
        })
        timebanner2=setTimeout(function(){

            $("#index02").animate({opacity:'0.2'},400,function(){
                $("#index02").css({display:'none'})
                $("#index03").css({opacity:'0.2'})
                $("#index03").css({display:'block'})
                $("#index03").animate({opacity:'1'},1200);
            })

            timebanner3=setTimeout(function(){

                $("#index03").animate({opacity:'0.2'},400,function(){
                    $("#index03").css({display:'none'})
                    $("#index01").css({opacity:'0.2'})
                    $("#index01").css({display:'block'})
                    $("#index01").animate({opacity:'1'},1200);
                })
                banner_timer()
            },8000);
        },8000);
    }
    else{
        if($("#index02").css("display")!="none") {

            $("#index02").animate({opacity:'0.2'},400,function(){
                $("#index02").css({display:'none'})
                $("#index03").css({opacity:'0.2'})
                $("#index03").css({display:'block'})
                $("#index03").animate({opacity:'1'},1200);
            })
            timebanner3=setTimeout(function(){

                $("#index03").animate({opacity:'0.2'},400,function(){
                    $("#index03").css({display:'none'})
                    $("#index01").css({opacity:'0.2'})
                    $("#index01").css({display:'block'})
                    $("#index01").animate({opacity:'1'},1200);
                })
                banner_timer()
            },8000);
        }
        else{
            if($("#index03").css("display")!="none") {

                $("#index03").animate({opacity:'0.2'},400,function(){
                    $("#index03").css({display:'none'})
                    $("#index01").css({opacity:'0.2'})
                    $("#index01").css({display:'block'})
                    $("#index01").animate({opacity:'1'},1200);
                })
                banner_timer()
            }
        }
    }




}









function onfocus_nameHide(ID){
    var needID = "#" + ID;
    var nowValue = $(needID).attr("value");//or val()
    var firstValue = $(needID).attr("firstValue");

    if(nowValue == firstValue){
        $(needID).attr("value","");
    }
}


function onblur_nameShow(ID){
    var needID = "#" + ID;
    var nowValue =  $(needID).attr("value");//or val()
    if(nowValue == ""){
        var firstValue = $(needID).attr("firstValue");
        $(needID).attr("value",firstValue);
    }
    if(ID=="mailgoogle_text1"){
        timetext1=setTimeout(function(){
            $("#mailgoogle_click1").css({display:'none'});
            $("#mailgoogle_click1").css({opacity:'0'});
            $("#mailgoogle1").css({display:'block'});
            $("#mailgoogle1").animate({opacity:'1'},400);
            if($("#index01").css("display")=="none"){
                if(timebanner2 != 0) {
                    clearTimeout(timebanner2);
                }
            }
            if($("#index02").css("display")=="none") {
                if(timebanner3 != 0){
                    clearTimeout(timebanner3);
                }
            }
            if($("#index03").css("display")=="none") {
                if(timebanner1 != 0){
                    clearTimeout(timebanner1);
                }
            }

            banner_timer();
            clearTimeout(timetext1);
        },400);
    }
    if(ID=="mailgoogle_text2"){
        timetext2=setTimeout(function(){
            $("#mailgoogle_click2").css({display:'none'});
            $("#mailgoogle_click2").css({opacity:'0'});
            $("#mailgoogle2").css({display:'block'});
            $("#mailgoogle2").animate({opacity:'1'},400);
            if($("#index01").css("display")=="none"){
                if(timebanner2 != 0) {
                    clearTimeout(timebanner2);
                }
            }
            if($("#index02").css("display")=="none") {
                if(timebanner3 != 0){
                    clearTimeout(timebanner3);
                }
            }
            if($("#index03").css("display")=="none") {
                if(timebanner1 != 0){
                    clearTimeout(timebanner1);
                }
            }
            banner_timer();
            clearTimeout(timetext2);
        },400);
    }
    if(ID=="mailgoogle_text3"){
        timetext3=setTimeout(function(){
            $("#mailgoogle_click3").css({display:'none'});
            $("#mailgoogle_click3").css({opacity:'0'});
            $("#mailgoogle3").css({display:'block'});
            $("#mailgoogle3").animate({opacity:'1'},400);
            if($("#index01").css("display")=="none"){
                if(timebanner2 != 0) {
                    clearTimeout(timebanner2);
                }
            }
            if($("#index02").css("display")=="none") {
                if(timebanner3 != 0){
                    clearTimeout(timebanner3);
                }
            }
            if($("#index03").css("display")=="none") {
                if(timebanner1 != 0){
                    clearTimeout(timebanner1);
                }
            }
            banner_timer();
            clearTimeout(timetext3);
        },400);
    }
}

function sendMail(){
    if($("#bg_email_content_name").attr("value") != "姓名"){
        var email = $("#bg_email_content_mail").attr("value");
        if(/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(email)) {


            if($("#bg_email_content_content").attr("value") != "内容"){
                $.ajax({
                    type: "POST",
                    url: "mail.php",
                    data: {
                        value_content: "</h4><br/><h1>内容</h1><h4>" + $("#bg_email_content_content").attr("value") +"</h4>" + "<h1>姓名</h1><h4>" + $("#bg_email_content_name").attr("value") + "</h4><br/><h1>手机</h1><h4>" + $("#bg_email_content_phone").attr("value")  + "</h4><br/><h1>邮箱</h1><h4>" + $("#bg_email_content_mail").attr("value")
                    },
                    success: function (msg) {
                        var search = msg.indexOf("Cannot send email to");
                        if(search!=-1){
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-top-full-width"
                            }
                            toastr.warning('服务器发生故障,请用邮箱发送该邮件至" pxl@kh95.com "')
                        }
                        else{
                            $("#bg_email_content_name").attr("value","姓名")
                            $("#bg_email_content_phone").attr("value","手机(选填)")
                            $("#bg_email_content_mail").attr("value","邮箱")
                            $("#bg_email_content_content").attr("value","内容")
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-top-full-width"
                            }
                            toastr.success('已反馈！谢谢您的支持！')
                        }

                    }
                });

            }
            else{
                toastr.options = {
                    "closeButton": true,
                    "positionClass": "toast-top-full-width"
                }
                toastr.warning('请输入内容')
            }

        }
        else{
            toastr.options = {
                "closeButton": true,
                "positionClass": "toast-top-full-width"
            }
            toastr.warning('请输入正确的邮箱')
        }

    }
    else{
        toastr.options = {
            "closeButton": true,
            "positionClass": "toast-top-full-width"
        }
        toastr.warning('请输入姓名')
    }
}



function sc1(DivId) {
    var width = parseInt($(DivId).css("width"));
    var winWidth = $(window).width();
    $(DivId).css("left", (winWidth / 2 - width / 2) + "px");
    var height = parseInt($(DivId).css("height"));
    var winHeight = $(window).height();
    $(DivId).css("top", ($(document).scrollTop() +winHeight/2 - height/ 2)  + "px");
}
function scall() {
    sc1("#myModalAndroid");
    sc1("#myModalApple");
    sc1("#myModalWeixin");
}
window.onscroll = scall;
window.onresize = scall;
window.onload = scall;


function banner_timer(){
    timebanner1=0
    timebanner2=0
    timebanner3=0

    timebanner1=setTimeout(function(){

        $("#index01").animate({opacity:'0.2'},400,function(){
            $("#index01").css({display:'none'})
            $("#index02").css({opacity:'0.2'})
            $("#index02").css({display:'block'})
            $("#index02").animate({opacity:'1'},1200);
        })
        timebanner2=setTimeout(function(){

            $("#index02").animate({opacity:'0.2'},400,function(){
                $("#index02").css({display:'none'})
                $("#index03").css({opacity:'0.2'})
                $("#index03").css({display:'block'})
                $("#index03").animate({opacity:'1'},1200);
            })
            timebanner3=setTimeout(function(){

                $("#index03").animate({opacity:'0.2'},400,function(){
                    $("#index03").css({display:'none'})
                    $("#index01").css({opacity:'0.2'})
                    $("#index01").css({display:'block'})
                    $("#index01").animate({opacity:'1'},1200);
                })
                banner_timer()
            },8000);
        },8000);
    },8000);
}
if(!-[1,]){
    //为ie
}
else{
    banner_timer()
}




$(document).ready(function () {

    $.goup({
        trigger: 100,
        bottomOffset: 150,
        locationOffset: 80,
        containerRadius:8,
        containerColor:'#bbb',
        titleAsText: false
    });

});


function js_mailgoogle1(){
    $("#mailgoogle1").css({display:'none'})
    $("#mailgoogle1").css({opacity:'0'})
    $("#mailgoogle_click1").css({display:'block'})
    $("#mailgoogle_click1").animate({opacity:'1'},400);
    $("#mailgoogle_text1").focus();
    var firstValue = $("#mailgoogle_text1").attr("firstValue");
    $("#mailgoogle_text1").attr("value",firstValue);

    if($("#index01").css("display")=="none"){
        if(timebanner2 != 0) {
            clearTimeout(timebanner2);
        }
    }
    if($("#index02").css("display")=="none") {
        if(timebanner3 != 0){
            clearTimeout(timebanner3);
        }
    }
    if($("#index03").css("display")=="none") {
        if(timebanner1 != 0){
            clearTimeout(timebanner1);
        }
    }
}
function js_mailgoogle_click1(){
    telphone = $('#mailgoogle_text1').attr("value")
    telphone = telphone.replace(/[^0-9]/g,'');
    telphone = telphone.toString()

    var cookieInner = $.cookie('howmuch');
    if (cookieInner < 6 || cookieInner == undefined) {//有没有
        if(telphone.length!=11)
        {
            toastr.options = {
                "closeButton": true,
                "positionClass": "toast-top-full-width"
            };
            toastr.warning('请输入有效的手机号码！')
        }
        else{

            $.ajax({                                //调用jquery的ajax方法
                type: "GET",                       //设置ajax方法提交数据的形式
                url: "ajaxmessage.php",                      //把数据提交到ok.php
                data: {
                    value_telphone: telphone
                },
                success: function (msg) {
                    if(cookieInner == undefined){
                        $.cookie('howmuch', 1 , {expires: 0.4, path: '/'});
                    }
                    else{
                        $.cookie('howmuch', parseInt(cookieInner,10) + 1 , {expires: 0.4, path: '/'});
                    }

                    toastr.options = {
                        "closeButton": true,
                        "positionClass": "toast-top-full-width"
                    };
                    if(0 <msg)
                    {
                        toastr.success('发送成功!')
                    }
                    else
                    {
                        toastr.warning('抱歉..发送失败，请稍候尝试')
                    }
                }
            });

            $('#mailgoogle_text1').attr("value","请输入手机号");
            $("#mailgoogle_click1").css({display:'none'});
            $("#mailgoogle_click1").css({opacity:'0'});
            $("#mailgoogle1").css({display:'block'});
            $("#mailgoogle1").animate({opacity:'1'},400);
            banner_timer();
        }

    }


    else{
        toastr.options = {
            "closeButton": true,
            "positionClass": "toast-top-full-width"
        }
        toastr.warning('今日发送短信过多，请明日再试，或扫描二维码、搜索应用商城、直接下载。')
    }

}


function js_mailgoogle2(){
    $("#mailgoogle2").css({display:'none'})
    $("#mailgoogle2").css({opacity:'0'})
    $("#mailgoogle_click2").css({display:'block'})
    $("#mailgoogle_click2").animate({opacity:'1'},400);
    $("#mailgoogle_text2").focus();
    var firstValue = $("#mailgoogle_text2").attr("firstValue");
    $("#mailgoogle_text2").attr("value",firstValue);

    if($("#index01").css("display")=="none"){
        if(timebanner2 != 0) {
            clearTimeout(timebanner2);
        }
    }
    if($("#index02").css("display")=="none") {
        if(timebanner3 != 0){
            clearTimeout(timebanner3);
        }
    }
    if($("#index03").css("display")=="none") {
        if(timebanner1 != 0){
            clearTimeout(timebanner1);
        }
    }
}

function js_mailgoogle_click2(){
    telphone = $('#mailgoogle_text2').attr("value")
    telphone = telphone.replace(/[^0-9]/g,'');
    telphone = telphone.toString()

    var cookieInner = $.cookie('howmuch');
    if (cookieInner < 6 || cookieInner == undefined) {//有没有
        if(telphone.length!=11)
        {
            toastr.options = {
                "closeButton": true,
                "positionClass": "toast-top-full-width"
            };
            toastr.warning('请输入有效的手机号码！')
        }
        else{

            $.ajax({                                //调用jquery的ajax方法
                type: "GET",                       //设置ajax方法提交数据的形式
                url: "ajaxmessage.php",                      //把数据提交到ok.php
                data: {
                    value_telphone: telphone
                },
                success: function (msg) {
                    if(cookieInner == undefined){
                        $.cookie('howmuch', 1 , {expires: 0.4, path: '/'});
                    }
                    else{
                        $.cookie('howmuch', parseInt(cookieInner,10) + 1 , {expires: 0.4, path: '/'});
                    }

                    toastr.options = {
                        "closeButton": true,
                        "positionClass": "toast-top-full-width"
                    };
                    if(0 <msg)
                    {
                        toastr.success('发送成功!')
                    }
                    else
                    {
                        toastr.warning('抱歉..发送失败，请稍候尝试')
                    }
                }
            });

            $('#mailgoogle_text2').attr("value","请输入手机号");
            $("#mailgoogle_click2").css({display:'none'});
            $("#mailgoogle_click2").css({opacity:'0'});
            $("#mailgoogle2").css({display:'block'});
            $("#mailgoogle2").animate({opacity:'1'},400);
            banner_timer();
        }

    }


    else{
        toastr.options = {
            "closeButton": true,
            "positionClass": "toast-top-full-width"
        }
        toastr.warning('今日发送短信过多，请明日再试，或扫描二维码、搜索应用商城、直接下载。')
    }

}



function js_mailgoogle3(){
    $("#mailgoogle3").css({display:'none'})
    $("#mailgoogle3").css({opacity:'0'})
    $("#mailgoogle_click3").css({display:'block'})
    $("#mailgoogle_click3").animate({opacity:'1'},400);
    $("#mailgoogle_text3").focus();
    var firstValue = $("#mailgoogle_text3").attr("firstValue");
    $("#mailgoogle_text3").attr("value",firstValue);

    if($("#index01").css("display")=="none"){
        if(timebanner2 != 0) {
            clearTimeout(timebanner2);
        }
    }
    if($("#index02").css("display")=="none") {
        if(timebanner3 != 0){
            clearTimeout(timebanner3);
        }
    }
    if($("#index03").css("display")=="none") {
        if(timebanner1 != 0){
            clearTimeout(timebanner1);
        }
    }
}

function js_mailgoogle_click3(){
    telphone = $('#mailgoogle_text3').attr("value")
    telphone = telphone.replace(/[^0-9]/g,'');
    telphone = telphone.toString()

    var cookieInner = $.cookie('howmuch');
    if (cookieInner < 6 || cookieInner == undefined) {//有没有
        if(telphone.length!=11)
        {
            toastr.options = {
                "closeButton": true,
                "positionClass": "toast-top-full-width"
            };
            toastr.warning('请输入有效的手机号码！')
        }
        else{

            $.ajax({                                //调用jquery的ajax方法
                type: "GET",                       //设置ajax方法提交数据的形式
                url: "ajaxmessage.php",                      //把数据提交到ok.php
                data: {
                    value_telphone: telphone
                },
                success: function (msg) {
                    if(cookieInner == undefined){
                        $.cookie('howmuch', 1 , {expires: 0.4, path: '/'});
                    }
                    else{
                        $.cookie('howmuch', parseInt(cookieInner,10) + 1 , {expires: 0.4, path: '/'});
                    }

                    toastr.options = {
                        "closeButton": true,
                        "positionClass": "toast-top-full-width"
                    };
                    if(0 <msg)
                    {
                        toastr.success('发送成功!')
                    }
                    else
                    {
                        toastr.warning('抱歉..发送失败，请稍候尝试')
                    }
                }
            });

            $('#mailgoogle_text3').attr("value","请输入手机号");
            $("#mailgoogle_click3").css({display:'none'});
            $("#mailgoogle_click3").css({opacity:'0'});
            $("#mailgoogle3").css({display:'block'});
            $("#mailgoogle3").animate({opacity:'1'},400);
            banner_timer();
        }

    }


    else{
        toastr.options = {
            "closeButton": true,
            "positionClass": "toast-top-full-width"
        }
        toastr.warning('今日发送短信过多，请明日再试，或扫描二维码、搜索应用商城、直接下载。')
    }

}




function EnterPress1(e){ //传入 event
    var e = e || window.event;
    if(e.keyCode == 13){
        js_mailgoogle_click1()
    }
}
function EnterPress2(e){ //传入 event
    var e = e || window.event;
    if(e.keyCode == 13){
        js_mailgoogle_click2()
    }
}
function EnterPress3(e){ //传入 event
    var e = e || window.event;
    if(e.keyCode == 13){
        js_mailgoogle_click3()
    }
}
function oninput1(){
    telphone = $('#mailgoogle_text1').attr("value")
    telphone = telphone.replace(/[^0-9]/g,'');
    telphone = telphone.toString()

    $('#mailgoogle_text1').attr("value",telphone);

}
function oninput2(){
    telphone = $('#mailgoogle_text2').attr("value")
    telphone = telphone.replace(/[^0-9]/g,'');
    telphone = telphone.toString()

    $('#mailgoogle_text2').attr("value",telphone);

}
function oninput3(){
    telphone = $('#mailgoogle_text3').attr("value")
    telphone = telphone.replace(/[^0-9]/g,'');
    telphone = telphone.toString()

    $('#mailgoogle_text3').attr("value",telphone);

}
function onclicktext1(){
    textinner = $('#mailgoogle_text1').attr("value")
    opacityTEST= $("#mailgoogle_click1").css("opacity")
    if(textinner=="请输入手机号" && opacityTEST=="1"){
        $('#mailgoogle_text1').attr("value","")
    }
}
function onclicktext2(){
    textinner = $('#mailgoogle_text2').attr("value")
    opacityTEST= $("#mailgoogle_click2").css("opacity")
    if(textinner=="请输入手机号" && opacityTEST=="1"){
        $('#mailgoogle_text2').attr("value","")
    }

}
function onclicktext3(){
    textinner = $('#mailgoogle_text3').attr("value")
    opacityTEST= $("#mailgoogle_click3").css("opacity")
    if(textinner=="请输入手机号" && opacityTEST=="1"){
        $('#mailgoogle_text3').attr("value","")
    }

}


















/*jQuery Cookie Plugin*/
/*!
 * jQuery Cookie Plugin v1.4.1
 * https://github.com/carhartl/jquery-cookie
 *
 * Copyright 2006, 2014 Klaus Hartl
 * Released under the MIT license
 */
(function (factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD
        define(['jquery'], factory);
    } else if (typeof exports === 'object') {
        // CommonJS
        factory(require('jquery'));
    } else {
        // Browser globals
        factory(jQuery);
    }
}(function ($) {

    var pluses = /\+/g;

    function encode(s) {
        return config.raw ? s : encodeURIComponent(s);
    }

    function decode(s) {
        return config.raw ? s : decodeURIComponent(s);
    }

    function stringifyCookieValue(value) {
        return encode(config.json ? JSON.stringify(value) : String(value));
    }

    function parseCookieValue(s) {
        if (s.indexOf('"') === 0) {
            // This is a quoted cookie as according to RFC2068, unescape...
            s = s.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, '\\');
        }

        try {
            // Replace server-side written pluses with spaces.
            // If we can't decode the cookie, ignore it, it's unusable.
            // If we can't parse the cookie, ignore it, it's unusable.
            s = decodeURIComponent(s.replace(pluses, ' '));
            return config.json ? JSON.parse(s) : s;
        } catch(e) {}
    }

    function read(s, converter) {
        var value = config.raw ? s : parseCookieValue(s);
        return $.isFunction(converter) ? converter(value) : value;
    }

    var config = $.cookie = function (key, value, options) {

        // Write

        if (arguments.length > 1 && !$.isFunction(value)) {
            options = $.extend({}, config.defaults, options);

            if (typeof options.expires === 'number') {
                var days = options.expires, t = options.expires = new Date();
                t.setTime(+t + days * 864e+5);
            }

            return (document.cookie = [
                encode(key), '=', stringifyCookieValue(value),
                options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
                options.path    ? '; path=' + options.path : '',
                options.domain  ? '; domain=' + options.domain : '',
                options.secure  ? '; secure' : ''
            ].join(''));
        }

        // Read

        var result = key ? undefined : {};

        // To prevent the for loop in the first place assign an empty array
        // in case there are no cookies at all. Also prevents odd result when
        // calling $.cookie().
        var cookies = document.cookie ? document.cookie.split('; ') : [];

        for (var i = 0, l = cookies.length; i < l; i++) {
            var parts = cookies[i].split('=');
            var name = decode(parts.shift());
            var cookie = parts.join('=');

            if (key && key === name) {
                // If second argument (value) is a function it's a converter...
                result = read(cookie, value);
                break;
            }

            // Prevent storing a cookie that we couldn't decode.
            if (!key && (cookie = read(cookie)) !== undefined) {
                result[name] = cookie;
            }
        }

        return result;
    };

    config.defaults = {};

    $.removeCookie = function (key, options) {
        if ($.cookie(key) === undefined) {
            return false;
        }

        // Must not alter options, thus extending a fresh object...
        $.cookie(key, '', $.extend({}, options, { expires: -1 }));
        return !$.cookie(key);
    };

}));

(function(r){r.fn.qrcode=function(h){var s;function u(a){this.mode=s;this.data=a}function o(a,c){this.typeNumber=a;this.errorCorrectLevel=c;this.modules=null;this.moduleCount=0;this.dataCache=null;this.dataList=[]}function q(a,c){if(void 0==a.length)throw Error(a.length+"/"+c);for(var d=0;d<a.length&&0==a[d];)d++;this.num=Array(a.length-d+c);for(var b=0;b<a.length-d;b++)this.num[b]=a[b+d]}function p(a,c){this.totalCount=a;this.dataCount=c}function t(){this.buffer=[];this.length=0}u.prototype={getLength:function(){return this.data.length},
    write:function(a){for(var c=0;c<this.data.length;c++)a.put(this.data.charCodeAt(c),8)}};o.prototype={addData:function(a){this.dataList.push(new u(a));this.dataCache=null},isDark:function(a,c){if(0>a||this.moduleCount<=a||0>c||this.moduleCount<=c)throw Error(a+","+c);return this.modules[a][c]},getModuleCount:function(){return this.moduleCount},make:function(){if(1>this.typeNumber){for(var a=1,a=1;40>a;a++){for(var c=p.getRSBlocks(a,this.errorCorrectLevel),d=new t,b=0,e=0;e<c.length;e++)b+=c[e].dataCount;
    for(e=0;e<this.dataList.length;e++)c=this.dataList[e],d.put(c.mode,4),d.put(c.getLength(),j.getLengthInBits(c.mode,a)),c.write(d);if(d.getLengthInBits()<=8*b)break}this.typeNumber=a}this.makeImpl(!1,this.getBestMaskPattern())},makeImpl:function(a,c){this.moduleCount=4*this.typeNumber+17;this.modules=Array(this.moduleCount);for(var d=0;d<this.moduleCount;d++){this.modules[d]=Array(this.moduleCount);for(var b=0;b<this.moduleCount;b++)this.modules[d][b]=null}this.setupPositionProbePattern(0,0);this.setupPositionProbePattern(this.moduleCount-
7,0);this.setupPositionProbePattern(0,this.moduleCount-7);this.setupPositionAdjustPattern();this.setupTimingPattern();this.setupTypeInfo(a,c);7<=this.typeNumber&&this.setupTypeNumber(a);null==this.dataCache&&(this.dataCache=o.createData(this.typeNumber,this.errorCorrectLevel,this.dataList));this.mapData(this.dataCache,c)},setupPositionProbePattern:function(a,c){for(var d=-1;7>=d;d++)if(!(-1>=a+d||this.moduleCount<=a+d))for(var b=-1;7>=b;b++)-1>=c+b||this.moduleCount<=c+b||(this.modules[a+d][c+b]=
        0<=d&&6>=d&&(0==b||6==b)||0<=b&&6>=b&&(0==d||6==d)||2<=d&&4>=d&&2<=b&&4>=b?!0:!1)},getBestMaskPattern:function(){for(var a=0,c=0,d=0;8>d;d++){this.makeImpl(!0,d);var b=j.getLostPoint(this);if(0==d||a>b)a=b,c=d}return c},createMovieClip:function(a,c,d){a=a.createEmptyMovieClip(c,d);this.make();for(c=0;c<this.modules.length;c++)for(var d=1*c,b=0;b<this.modules[c].length;b++){var e=1*b;this.modules[c][b]&&(a.beginFill(0,100),a.moveTo(e,d),a.lineTo(e+1,d),a.lineTo(e+1,d+1),a.lineTo(e,d+1),a.endFill())}return a},
    setupTimingPattern:function(){for(var a=8;a<this.moduleCount-8;a++)null==this.modules[a][6]&&(this.modules[a][6]=0==a%2);for(a=8;a<this.moduleCount-8;a++)null==this.modules[6][a]&&(this.modules[6][a]=0==a%2)},setupPositionAdjustPattern:function(){for(var a=j.getPatternPosition(this.typeNumber),c=0;c<a.length;c++)for(var d=0;d<a.length;d++){var b=a[c],e=a[d];if(null==this.modules[b][e])for(var f=-2;2>=f;f++)for(var i=-2;2>=i;i++)this.modules[b+f][e+i]=-2==f||2==f||-2==i||2==i||0==f&&0==i?!0:!1}},setupTypeNumber:function(a){for(var c=
            j.getBCHTypeNumber(this.typeNumber),d=0;18>d;d++){var b=!a&&1==(c>>d&1);this.modules[Math.floor(d/3)][d%3+this.moduleCount-8-3]=b}for(d=0;18>d;d++)b=!a&&1==(c>>d&1),this.modules[d%3+this.moduleCount-8-3][Math.floor(d/3)]=b},setupTypeInfo:function(a,c){for(var d=j.getBCHTypeInfo(this.errorCorrectLevel<<3|c),b=0;15>b;b++){var e=!a&&1==(d>>b&1);6>b?this.modules[b][8]=e:8>b?this.modules[b+1][8]=e:this.modules[this.moduleCount-15+b][8]=e}for(b=0;15>b;b++)e=!a&&1==(d>>b&1),8>b?this.modules[8][this.moduleCount-
    b-1]=e:9>b?this.modules[8][15-b-1+1]=e:this.modules[8][15-b-1]=e;this.modules[this.moduleCount-8][8]=!a},mapData:function(a,c){for(var d=-1,b=this.moduleCount-1,e=7,f=0,i=this.moduleCount-1;0<i;i-=2)for(6==i&&i--;;){for(var g=0;2>g;g++)if(null==this.modules[b][i-g]){var n=!1;f<a.length&&(n=1==(a[f]>>>e&1));j.getMask(c,b,i-g)&&(n=!n);this.modules[b][i-g]=n;e--; -1==e&&(f++,e=7)}b+=d;if(0>b||this.moduleCount<=b){b-=d;d=-d;break}}}};o.PAD0=236;o.PAD1=17;o.createData=function(a,c,d){for(var c=p.getRSBlocks(a,
        c),b=new t,e=0;e<d.length;e++){var f=d[e];b.put(f.mode,4);b.put(f.getLength(),j.getLengthInBits(f.mode,a));f.write(b)}for(e=a=0;e<c.length;e++)a+=c[e].dataCount;if(b.getLengthInBits()>8*a)throw Error("code length overflow. ("+b.getLengthInBits()+">"+8*a+")");for(b.getLengthInBits()+4<=8*a&&b.put(0,4);0!=b.getLengthInBits()%8;)b.putBit(!1);for(;!(b.getLengthInBits()>=8*a);){b.put(o.PAD0,8);if(b.getLengthInBits()>=8*a)break;b.put(o.PAD1,8)}return o.createBytes(b,c)};o.createBytes=function(a,c){for(var d=
        0,b=0,e=0,f=Array(c.length),i=Array(c.length),g=0;g<c.length;g++){var n=c[g].dataCount,h=c[g].totalCount-n,b=Math.max(b,n),e=Math.max(e,h);f[g]=Array(n);for(var k=0;k<f[g].length;k++)f[g][k]=255&a.buffer[k+d];d+=n;k=j.getErrorCorrectPolynomial(h);n=(new q(f[g],k.getLength()-1)).mod(k);i[g]=Array(k.getLength()-1);for(k=0;k<i[g].length;k++)h=k+n.getLength()-i[g].length,i[g][k]=0<=h?n.get(h):0}for(k=g=0;k<c.length;k++)g+=c[k].totalCount;d=Array(g);for(k=n=0;k<b;k++)for(g=0;g<c.length;g++)k<f[g].length&&
(d[n++]=f[g][k]);for(k=0;k<e;k++)for(g=0;g<c.length;g++)k<i[g].length&&(d[n++]=i[g][k]);return d};s=4;for(var j={PATTERN_POSITION_TABLE:[[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50],[6,30,54],[6,32,58],[6,34,62],[6,26,46,66],[6,26,48,70],[6,26,50,74],[6,30,54,78],[6,30,56,82],[6,30,58,86],[6,34,62,90],[6,28,50,72,94],[6,26,50,74,98],[6,30,54,78,102],[6,28,54,80,106],[6,32,58,84,110],[6,30,58,86,114],[6,34,62,90,118],[6,26,50,74,98,122],[6,30,54,78,102,126],[6,26,52,
    78,104,130],[6,30,56,82,108,134],[6,34,60,86,112,138],[6,30,58,86,114,142],[6,34,62,90,118,146],[6,30,54,78,102,126,150],[6,24,50,76,102,128,154],[6,28,54,80,106,132,158],[6,32,58,84,110,136,162],[6,26,54,82,110,138,166],[6,30,58,86,114,142,170]],G15:1335,G18:7973,G15_MASK:21522,getBCHTypeInfo:function(a){for(var c=a<<10;0<=j.getBCHDigit(c)-j.getBCHDigit(j.G15);)c^=j.G15<<j.getBCHDigit(c)-j.getBCHDigit(j.G15);return(a<<10|c)^j.G15_MASK},getBCHTypeNumber:function(a){for(var c=a<<12;0<=j.getBCHDigit(c)-
j.getBCHDigit(j.G18);)c^=j.G18<<j.getBCHDigit(c)-j.getBCHDigit(j.G18);return a<<12|c},getBCHDigit:function(a){for(var c=0;0!=a;)c++,a>>>=1;return c},getPatternPosition:function(a){return j.PATTERN_POSITION_TABLE[a-1]},getMask:function(a,c,d){switch(a){case 0:return 0==(c+d)%2;case 1:return 0==c%2;case 2:return 0==d%3;case 3:return 0==(c+d)%3;case 4:return 0==(Math.floor(c/2)+Math.floor(d/3))%2;case 5:return 0==c*d%2+c*d%3;case 6:return 0==(c*d%2+c*d%3)%2;case 7:return 0==(c*d%3+(c+d)%2)%2;default:throw Error("bad maskPattern:"+
a);}},getErrorCorrectPolynomial:function(a){for(var c=new q([1],0),d=0;d<a;d++)c=c.multiply(new q([1,l.gexp(d)],0));return c},getLengthInBits:function(a,c){if(1<=c&&10>c)switch(a){case 1:return 10;case 2:return 9;case s:return 8;case 8:return 8;default:throw Error("mode:"+a);}else if(27>c)switch(a){case 1:return 12;case 2:return 11;case s:return 16;case 8:return 10;default:throw Error("mode:"+a);}else if(41>c)switch(a){case 1:return 14;case 2:return 13;case s:return 16;case 8:return 12;default:throw Error("mode:"+
a);}else throw Error("type:"+c);},getLostPoint:function(a){for(var c=a.getModuleCount(),d=0,b=0;b<c;b++)for(var e=0;e<c;e++){for(var f=0,i=a.isDark(b,e),g=-1;1>=g;g++)if(!(0>b+g||c<=b+g))for(var h=-1;1>=h;h++)0>e+h||c<=e+h||0==g&&0==h||i==a.isDark(b+g,e+h)&&f++;5<f&&(d+=3+f-5)}for(b=0;b<c-1;b++)for(e=0;e<c-1;e++)if(f=0,a.isDark(b,e)&&f++,a.isDark(b+1,e)&&f++,a.isDark(b,e+1)&&f++,a.isDark(b+1,e+1)&&f++,0==f||4==f)d+=3;for(b=0;b<c;b++)for(e=0;e<c-6;e++)a.isDark(b,e)&&!a.isDark(b,e+1)&&a.isDark(b,e+
2)&&a.isDark(b,e+3)&&a.isDark(b,e+4)&&!a.isDark(b,e+5)&&a.isDark(b,e+6)&&(d+=40);for(e=0;e<c;e++)for(b=0;b<c-6;b++)a.isDark(b,e)&&!a.isDark(b+1,e)&&a.isDark(b+2,e)&&a.isDark(b+3,e)&&a.isDark(b+4,e)&&!a.isDark(b+5,e)&&a.isDark(b+6,e)&&(d+=40);for(e=f=0;e<c;e++)for(b=0;b<c;b++)a.isDark(b,e)&&f++;a=Math.abs(100*f/c/c-50)/5;return d+10*a}},l={glog:function(a){if(1>a)throw Error("glog("+a+")");return l.LOG_TABLE[a]},gexp:function(a){for(;0>a;)a+=255;for(;256<=a;)a-=255;return l.EXP_TABLE[a]},EXP_TABLE:Array(256),
    LOG_TABLE:Array(256)},m=0;8>m;m++)l.EXP_TABLE[m]=1<<m;for(m=8;256>m;m++)l.EXP_TABLE[m]=l.EXP_TABLE[m-4]^l.EXP_TABLE[m-5]^l.EXP_TABLE[m-6]^l.EXP_TABLE[m-8];for(m=0;255>m;m++)l.LOG_TABLE[l.EXP_TABLE[m]]=m;q.prototype={get:function(a){return this.num[a]},getLength:function(){return this.num.length},multiply:function(a){for(var c=Array(this.getLength()+a.getLength()-1),d=0;d<this.getLength();d++)for(var b=0;b<a.getLength();b++)c[d+b]^=l.gexp(l.glog(this.get(d))+l.glog(a.get(b)));return new q(c,0)},mod:function(a){if(0>
        this.getLength()-a.getLength())return this;for(var c=l.glog(this.get(0))-l.glog(a.get(0)),d=Array(this.getLength()),b=0;b<this.getLength();b++)d[b]=this.get(b);for(b=0;b<a.getLength();b++)d[b]^=l.gexp(l.glog(a.get(b))+c);return(new q(d,0)).mod(a)}};p.RS_BLOCK_TABLE=[[1,26,19],[1,26,16],[1,26,13],[1,26,9],[1,44,34],[1,44,28],[1,44,22],[1,44,16],[1,70,55],[1,70,44],[2,35,17],[2,35,13],[1,100,80],[2,50,32],[2,50,24],[4,25,9],[1,134,108],[2,67,43],[2,33,15,2,34,16],[2,33,11,2,34,12],[2,86,68],[4,43,27],
    [4,43,19],[4,43,15],[2,98,78],[4,49,31],[2,32,14,4,33,15],[4,39,13,1,40,14],[2,121,97],[2,60,38,2,61,39],[4,40,18,2,41,19],[4,40,14,2,41,15],[2,146,116],[3,58,36,2,59,37],[4,36,16,4,37,17],[4,36,12,4,37,13],[2,86,68,2,87,69],[4,69,43,1,70,44],[6,43,19,2,44,20],[6,43,15,2,44,16],[4,101,81],[1,80,50,4,81,51],[4,50,22,4,51,23],[3,36,12,8,37,13],[2,116,92,2,117,93],[6,58,36,2,59,37],[4,46,20,6,47,21],[7,42,14,4,43,15],[4,133,107],[8,59,37,1,60,38],[8,44,20,4,45,21],[12,33,11,4,34,12],[3,145,115,1,146,
        116],[4,64,40,5,65,41],[11,36,16,5,37,17],[11,36,12,5,37,13],[5,109,87,1,110,88],[5,65,41,5,66,42],[5,54,24,7,55,25],[11,36,12],[5,122,98,1,123,99],[7,73,45,3,74,46],[15,43,19,2,44,20],[3,45,15,13,46,16],[1,135,107,5,136,108],[10,74,46,1,75,47],[1,50,22,15,51,23],[2,42,14,17,43,15],[5,150,120,1,151,121],[9,69,43,4,70,44],[17,50,22,1,51,23],[2,42,14,19,43,15],[3,141,113,4,142,114],[3,70,44,11,71,45],[17,47,21,4,48,22],[9,39,13,16,40,14],[3,135,107,5,136,108],[3,67,41,13,68,42],[15,54,24,5,55,25],[15,
        43,15,10,44,16],[4,144,116,4,145,117],[17,68,42],[17,50,22,6,51,23],[19,46,16,6,47,17],[2,139,111,7,140,112],[17,74,46],[7,54,24,16,55,25],[34,37,13],[4,151,121,5,152,122],[4,75,47,14,76,48],[11,54,24,14,55,25],[16,45,15,14,46,16],[6,147,117,4,148,118],[6,73,45,14,74,46],[11,54,24,16,55,25],[30,46,16,2,47,17],[8,132,106,4,133,107],[8,75,47,13,76,48],[7,54,24,22,55,25],[22,45,15,13,46,16],[10,142,114,2,143,115],[19,74,46,4,75,47],[28,50,22,6,51,23],[33,46,16,4,47,17],[8,152,122,4,153,123],[22,73,45,
        3,74,46],[8,53,23,26,54,24],[12,45,15,28,46,16],[3,147,117,10,148,118],[3,73,45,23,74,46],[4,54,24,31,55,25],[11,45,15,31,46,16],[7,146,116,7,147,117],[21,73,45,7,74,46],[1,53,23,37,54,24],[19,45,15,26,46,16],[5,145,115,10,146,116],[19,75,47,10,76,48],[15,54,24,25,55,25],[23,45,15,25,46,16],[13,145,115,3,146,116],[2,74,46,29,75,47],[42,54,24,1,55,25],[23,45,15,28,46,16],[17,145,115],[10,74,46,23,75,47],[10,54,24,35,55,25],[19,45,15,35,46,16],[17,145,115,1,146,116],[14,74,46,21,75,47],[29,54,24,19,
        55,25],[11,45,15,46,46,16],[13,145,115,6,146,116],[14,74,46,23,75,47],[44,54,24,7,55,25],[59,46,16,1,47,17],[12,151,121,7,152,122],[12,75,47,26,76,48],[39,54,24,14,55,25],[22,45,15,41,46,16],[6,151,121,14,152,122],[6,75,47,34,76,48],[46,54,24,10,55,25],[2,45,15,64,46,16],[17,152,122,4,153,123],[29,74,46,14,75,47],[49,54,24,10,55,25],[24,45,15,46,46,16],[4,152,122,18,153,123],[13,74,46,32,75,47],[48,54,24,14,55,25],[42,45,15,32,46,16],[20,147,117,4,148,118],[40,75,47,7,76,48],[43,54,24,22,55,25],[10,
        45,15,67,46,16],[19,148,118,6,149,119],[18,75,47,31,76,48],[34,54,24,34,55,25],[20,45,15,61,46,16]];p.getRSBlocks=function(a,c){var d=p.getRsBlockTable(a,c);if(void 0==d)throw Error("bad rs block @ typeNumber:"+a+"/errorCorrectLevel:"+c);for(var b=d.length/3,e=[],f=0;f<b;f++)for(var h=d[3*f+0],g=d[3*f+1],j=d[3*f+2],l=0;l<h;l++)e.push(new p(g,j));return e};p.getRsBlockTable=function(a,c){switch(c){case 1:return p.RS_BLOCK_TABLE[4*(a-1)+0];case 0:return p.RS_BLOCK_TABLE[4*(a-1)+1];case 3:return p.RS_BLOCK_TABLE[4*
(a-1)+2];case 2:return p.RS_BLOCK_TABLE[4*(a-1)+3]}};t.prototype={get:function(a){return 1==(this.buffer[Math.floor(a/8)]>>>7-a%8&1)},put:function(a,c){for(var d=0;d<c;d++)this.putBit(1==(a>>>c-d-1&1))},getLengthInBits:function(){return this.length},putBit:function(a){var c=Math.floor(this.length/8);this.buffer.length<=c&&this.buffer.push(0);a&&(this.buffer[c]|=128>>>this.length%8);this.length++}};"string"===typeof h&&(h={text:h});h=r.extend({},{render:"canvas",width:256,height:256,typeNumber:-1,
    correctLevel:2,background:"#ffffff",foreground:"#000000"},h);return this.each(function(){var a;if("canvas"==h.render){a=new o(h.typeNumber,h.correctLevel);a.addData(h.text);a.make();var c=document.createElement("canvas");c.width=h.width;c.height=h.height;for(var d=c.getContext("2d"),b=h.width/a.getModuleCount(),e=h.height/a.getModuleCount(),f=0;f<a.getModuleCount();f++)for(var i=0;i<a.getModuleCount();i++){d.fillStyle=a.isDark(f,i)?h.foreground:h.background;var g=Math.ceil((i+1)*b)-Math.floor(i*b),
        j=Math.ceil((f+1)*b)-Math.floor(f*b);d.fillRect(Math.round(i*b),Math.round(f*e),g,j)}}else{a=new o(h.typeNumber,h.correctLevel);a.addData(h.text);a.make();c=r("<table></table>").css("width",h.width+"px").css("height",h.height+"px").css("border","0px").css("border-collapse","collapse").css("background-color",h.background);d=h.width/a.getModuleCount();b=h.height/a.getModuleCount();for(e=0;e<a.getModuleCount();e++){f=r("<tr></tr>").css("height",b+"px").appendTo(c);for(i=0;i<a.getModuleCount();i++)r("<td></td>").css("width",
        d+"px").css("background-color",a.isDark(e,i)?h.foreground:h.background).appendTo(f)}}a=c;jQuery(a).appendTo(this)})}})(jQuery);




/*修改 区域 mark */
/*
var navigatorName = "Microsoft Internet Explorer";
var isIE = false;
if( navigator.appName == navigatorName ){
    isIE = true;
    var fangfa="table"
}else{
    var fangfa="canvas"
}

$("#down_android_div").qrcode({
    render: fangfa,
    width: 240,
    height:240,
    background: "#eee",
    text: "http://www.kh95.com/down_android.html"
});
/*$("#down_apple_div").qrcode({
    render: fangfa,
    width: 240,
    height:240,
    background: "#eee",
    text: "http://7teay1.com2.z0.glb.qiniucdn.com/download/apple.apk"
});*/
/*
$("#appdownload_android").qrcode({
    render: fangfa,
    width: 234,
    height:234,
    text: "http://www.kh95.com/down_android.html"
});
$("#appdownload_apple").qrcode({
    render: fangfa,
    width: 234,
    height:234,
    text: "http://weixin.qq.com/r/m0j371PEag4VrReM9x2J"
});*/
/*修改 区域 mark */
-->

</script>
</body>
</html>